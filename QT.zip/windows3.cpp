#include "windows3.h"
#include "ui_windows3.h"

windows3::windows3(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::windows3)
{
    ui->setupUi(this);
}

windows3::~windows3()
{
    delete ui;
}

void windows3::on_pushButton_exit_clicked()
{
    close();
}


void windows3::on_pushButton_interest_clicked()
{
    QString tem;
    double money1, money2, time, rate1, rate2;
    double mMoney, tMoney, tInterest;
    tem = ui->lineEdit_money1->text();
    money1 = tem.toDouble();
    tem = ui->lineEdit_money2->text();
    money2 = tem.toDouble();
    tem = ui->lineEdit_time->text();
    time= tem.toDouble();
    tem = ui->lineEdit_rate1->text();
    rate1= tem.toDouble();
    tem = ui->lineEdit_rate2->text();
    rate2= tem.toDouble();
    mMoney = (money1*100*(rate1/12)*pow((1+rate1/1200),time))/(pow((1+rate1/1200),time)-1) + (money2*100*(rate2/12)*pow((1+rate2/1200),time))/(pow((1+rate2/1200),time)-1);
    tMoney = mMoney * time;
    tInterest = mMoney - (money1+money2)*10000;
    ui->textEdit_result->setText("每月月供:"+QString::number(mMoney,10,2)+"\n"+"总还款金额:"+QString::number(tMoney,10,2)+"\n"+"总利息："+QString::number(tInterest,10,2));

}

void windows3::on_pushButton_principal_clicked()
{
    QString tem;
    double money1, money2, time, rate1, rate2;
    double mMoney, tMoney, tInterest, mDecline;
    tem = ui->lineEdit_money1->text();
    money1 = tem.toDouble();
    tem = ui->lineEdit_money2->text();
    money2 = tem.toDouble();
    tem = ui->lineEdit_time->text();
    time= tem.toDouble();
    tem = ui->lineEdit_rate1->text();
    rate1= tem.toDouble();
    tem = ui->lineEdit_rate2->text();
    rate2= tem.toDouble();
    mMoney = money1*10000/time + money1*100*rate1/12 + money2*10000/time + money2*100*rate2/12;
    mDecline = mDecline,1*(rate1/12)*100/time + money2*(rate2/12)*100/time;
    tMoney = mMoney*time - mDecline*time*(time-1)/2;
    tInterest = tMoney - (money1+money2)*10000;
    ui->textEdit_result->setText("首月月供:"+QString::number(mMoney,10,2)+"\n"+"每月递减:"+QString::number(mDecline,10,2)+"\n"+"总还款金额:"+QString::number(tMoney,10,2)+"\n"+"总利息："+QString::number(tInterest,10,2));
}

