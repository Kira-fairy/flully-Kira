#ifndef WINDOWS3_H
#define WINDOWS3_H

#include <QMainWindow>

namespace Ui {
class windows3;
}

class windows3 : public QMainWindow
{
    Q_OBJECT

public:
    explicit windows3(QWidget *parent = 0);
    ~windows3();

private slots:
    void on_pushButton_exit_clicked();

    void on_pushButton_jin_clicked();

    void on_pushButton_interest_clicked();

    void on_pushButton_principal_clicked();

private:
    Ui::windows3 *ui;
};

#endif // WINDOWS3_H
