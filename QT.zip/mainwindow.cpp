#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_exit_clicked()
{
    close();
}

void MainWindow::on_pushButton_windows1_clicked()
{
    p1=new windows1;
    p1->show();
}

void MainWindow::on_pushButton_windows2_clicked()
{
    p2=new windows2;
    p2->show();
}

void MainWindow::on_pushButton_windows3_clicked()
{
    p3=new windows3;
    p3->show();
}
