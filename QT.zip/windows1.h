#ifndef WINDOWS1_H
#define WINDOWS1_H

#include <QMainWindow>

namespace Ui {
class windows1;
}

class windows1 : public QMainWindow
{
    Q_OBJECT

public:
    explicit windows1(QWidget *parent = 0);
    ~windows1();

private slots:
    void on_pushButton_exit_clicked();

    void on_pushButton_interest_clicked();

    void on_pushButton_principal_clicked();

private:
    Ui::windows1 *ui;
};

#endif // WINDOWS1_H
